<?php
$cnmysql = new mysqli("localhost","root","","bibliotecaon");

?>